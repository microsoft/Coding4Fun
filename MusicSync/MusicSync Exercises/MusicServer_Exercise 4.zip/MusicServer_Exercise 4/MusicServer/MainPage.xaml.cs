﻿using System;
using System.Diagnostics;
using Windows.Networking.Connectivity;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace MusicServer
{
    public sealed partial class MainPage : Page
    {
        private StorageFile _mediaFile;
        private Publisher _publisher;
        private Subscriber _subscriber;

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            //get the current IP address of this machine and display it
            HostIPAddressTextBlock.Text = GetThisIPAddress();
            //set up as a publisher and bind the UI to the list of virtual speakers
            _publisher = new Publisher();
            MessageLogListView.ItemsSource = _publisher.Speakers;
            bool init = await _publisher.Initialize();

            if (init)
            {
                //allow a new media file to be selected
                SelectMediaFileButton.IsEnabled = true;
                // create a virtual speaker for this local machine to listen to the music we send
                _subscriber = new Subscriber();
                //hardcoded to localhost and name for local speaker
                _subscriber.ConnectAsync("localhost", "Host Speaker");
            }
            else
            {
                Debug.WriteLine("Error: Publisher failed to initialize");
            }
        }

        private async void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            // load filepicker for user to select a media file
            FileOpenPicker filePicker = new FileOpenPicker();
            filePicker.SuggestedStartLocation = PickerLocationId.MusicLibrary;
            filePicker.FileTypeFilter.Add(".mp4");
            filePicker.FileTypeFilter.Add(".MOV");
            filePicker.FileTypeFilter.Add(".mp3");
            filePicker.FileTypeFilter.Add(".wav");
            filePicker.ViewMode = PickerViewMode.Thumbnail;

            _mediaFile = await filePicker.PickSingleFileAsync();

            if (_mediaFile != null)
            {
                Debug.WriteLine(_mediaFile.DisplayName);
                SendButton.IsEnabled = true;
            }

        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            // read the file and send it via the publisher 
            using (IRandomAccessStream stream = await _mediaFile.OpenReadAsync())
            {
                byte[] fileBytes = new byte[stream.Size];
                using (DataReader reader = new DataReader(stream))
                {
                    await reader.LoadAsync((uint)stream.Size);
                    reader.ReadBytes(fileBytes);
                }
                _publisher.Send(fileBytes);
            }
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: send the Stop or Play commands to virtual speakers
        }

        private string GetThisIPAddress()
        {
            string lastHostName = "";
            var hosts = NetworkInformation.GetHostNames();
            foreach (var host in hosts)
            {
                // The last host name is always this computer.
                if (host.Type == Windows.Networking.HostNameType.Ipv4)
                {
                    lastHostName = host.DisplayName;
                }
            }
            return lastHostName;
        }
    }
}
