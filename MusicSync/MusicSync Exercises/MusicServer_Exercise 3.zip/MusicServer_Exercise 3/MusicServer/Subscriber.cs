﻿using System;
using System.Diagnostics;
using Windows.Networking;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace MusicServer
{
    public class Subscriber
    {
        // two streams in memory.
        // One stream is used to receive the file
        // the other is used to play the file
        private static IRandomAccessStream _incomingStream;
        private static IRandomAccessStream _playingStream;

        private StreamSocket _socket;
        private DataWriter _writer;

        public Subscriber()
        {
            //the two streams actually point to the same underlying data 
            _incomingStream = new InMemoryRandomAccessStream();
            _playingStream = _incomingStream.CloneStream();
        }

        public async void ConnectAsync(string host, string name)
        {
            HostName hostName;
            try
            {
                hostName = new HostName(host);
            }
            catch (ArgumentException)
            {
                Debug.WriteLine("Error: Invalid host name {0}.", host);
                return;
            }

            _socket = new StreamSocket();
            _socket.Control.KeepAlive = true;
            _socket.Control.QualityOfService = SocketQualityOfService.LowLatency;

            //hard coded port - can be user-specified but to keep this sample simple it is 21121
            await _socket.ConnectAsync(hostName, "21121");
            Debug.WriteLine("Connected");

            //first message to send is the name of this virtual speaker
            _writer = new DataWriter(_socket.OutputStream);
            _writer.WriteUInt32(_writer.MeasureString(name));
            _writer.WriteString(name);

            try
            {
                await _writer.StoreAsync();
                Debug.WriteLine("{0} registered successfully.", name);
            }
            catch (Exception exception)
            {
                Debug.WriteLine("Send failed with error: " + exception.Message);
                // If this is an unknown status it means that the error if fatal and retry will likely fail.
                if (SocketError.GetStatus(exception.HResult) == SocketErrorStatus.Unknown)
                {
                    throw;
                }
            }
        }
    }
}
