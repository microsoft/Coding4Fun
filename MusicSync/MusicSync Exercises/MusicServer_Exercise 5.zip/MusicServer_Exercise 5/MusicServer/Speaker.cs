﻿using System;
using Windows.Networking.Sockets;

namespace MusicServer
{
    public class Speaker
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Status { get; set; }
        public StreamSocket Socket { get; set; }

        public override string ToString()
        {
            return String.Format("{0}:{1}   {2}", Name, Address, Status);
        }
    }
}
