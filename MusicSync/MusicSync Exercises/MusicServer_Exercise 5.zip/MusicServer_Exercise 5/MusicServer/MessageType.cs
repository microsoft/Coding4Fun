﻿namespace MusicServer
{
    public enum MessageType
    {
        Unknown,
        Message,
        Media,
        Play,
        Stop,
        Ready
    }
}
