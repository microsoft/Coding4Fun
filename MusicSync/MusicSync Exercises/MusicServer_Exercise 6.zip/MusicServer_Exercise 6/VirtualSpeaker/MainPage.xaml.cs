﻿using Windows.Networking.Connectivity;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using MusicSubscriber;

namespace VirtualSpeaker
{
    public sealed partial class MainPage : Page
    {
        private Subscriber _subscriber;

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            HostIPAddressTextBlock.Text = GetThisIPAddress();
            _subscriber = new Subscriber();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            string host = HostNameTextBox.Text;
            string name = SpeakerNameTextBox.Text;
            _subscriber.ConnectAsync(host, name);
        }

        private string GetThisIPAddress()
        {
            string lastHostName = "";
            var hosts = NetworkInformation.GetHostNames();
            foreach (var host in hosts)
            {
                // The last host name is always this computer.
                if (host.Type == Windows.Networking.HostNameType.Ipv4)
                {
                    lastHostName = host.DisplayName;
                }
            }
            return lastHostName;
        }
    }
}
