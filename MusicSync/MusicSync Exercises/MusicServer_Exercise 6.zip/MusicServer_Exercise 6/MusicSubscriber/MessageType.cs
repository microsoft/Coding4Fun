﻿namespace MusicSubscriber
{
    public enum MessageType
    {
        Unknown,
        Message,
        Media,
        Play,
        Stop,
        Ready
    }
}
