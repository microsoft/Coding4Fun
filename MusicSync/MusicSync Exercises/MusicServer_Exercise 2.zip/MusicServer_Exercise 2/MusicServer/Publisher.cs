﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.Networking.Sockets;

namespace MusicServer
{
    public class Publisher
    {
        // this is a the port number in a released app this should be configurable
        private const string SERVICE_NAME = "21121";
        // this max packet size is used in case of a poor internet connection in order to get the packet in reasonable size transferred
        private const int MAX_PACKET_SIZE = 10000;
        private StreamSocketListener _listener;
        //the collection of virtual speakers
        // observable so that the UI can update when it changes
        private ObservableCollection<Speaker> _speakers;
        public ObservableCollection<Speaker> Speakers
        {
            get
            {
                if (_speakers == null)
                {
                    _speakers = new ObservableCollection<Speaker>();
                }
                return _speakers;
            }
        }

        public async Task<bool> Initialize()
        {
            bool success = true;
            try
            {
                //set up a listener socket for speakers to connect with
                _listener = new StreamSocketListener();
                _listener.Control.KeepAlive = true;
                _listener.Control.QualityOfService = SocketQualityOfService.LowLatency;
                _listener.ConnectionReceived += Listener_ConnectionReceived;
                await _listener.BindServiceNameAsync(SERVICE_NAME);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error: " + ex);
                success = false;
            }

            return success;
        }

        private void Listener_ConnectionReceived(
            StreamSocketListener sender,
            StreamSocketListenerConnectionReceivedEventArgs args)
        {
            // TODO: add connected client to list of speakers
        }
    }
}
