﻿using System;
using System.Diagnostics;
using Windows.Networking.Connectivity;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace MusicServer
{
    public sealed partial class MainPage : Page
    {
        private StorageFile _mediaFile;

        public MainPage()
        {
            this.InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            //get the current IP address of this machine and display it
            HostIPAddressTextBlock.Text = GetThisIPAddress();
            SelectMediaFileButton.IsEnabled = true;
            // TODO: initialize publisher and load in virtual speakers.
        }

        private async void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            // load filepicker for user to select a media file
            FileOpenPicker filePicker = new FileOpenPicker();
            filePicker.SuggestedStartLocation = PickerLocationId.MusicLibrary;
            filePicker.FileTypeFilter.Add(".mp4");
            filePicker.FileTypeFilter.Add(".MOV");
            filePicker.FileTypeFilter.Add(".mp3");
            filePicker.FileTypeFilter.Add(".wav");
            filePicker.ViewMode = PickerViewMode.Thumbnail;

            _mediaFile = await filePicker.PickSingleFileAsync();

            if (_mediaFile != null)
            {
                Debug.WriteLine(_mediaFile.DisplayName);
                SendButton.IsEnabled = true;
            }

        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: send the media file to remote speakers
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            // TODO: send the Stop or Play commands to virtual speakers
        }

        private string GetThisIPAddress()
        {
            string lastHostName = "";
            var hosts = NetworkInformation.GetHostNames();
            foreach (var host in hosts)
            {
                // The last host name is always this computer.
                if (host.Type == Windows.Networking.HostNameType.Ipv4)
                {
                    lastHostName = host.DisplayName;
                }
            }
            return lastHostName;
        }
    }
}
