﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;
using Windows.Media.Ocr;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace CardReader
{
    public sealed partial class MainPage : Page
    {
        private DeviceInformationCollection _allVideoDevices;
        private DeviceInformation _desiredDevice;
        private MediaCapture _mediaCapture;
        private StorageFile _photoFile;
        private OcrEngine _ocrEngine;

        public MainPage()
        {
            this.InitializeComponent();
            Loaded += MainPage_Loaded;

            // Init OCR engine with English language.
            _ocrEngine = OcrEngine.TryCreateFromLanguage(new Language("en"));
        }

        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            // Get available devices for capturing media and list them 
            _allVideoDevices = await DeviceInformation.FindAllAsync(DeviceClass.VideoCapture);

            if (_allVideoDevices == null || !_allVideoDevices.Any())
            {
                Debug.WriteLine("No devices found.");
                return;
            }
            //add to  device list
            foreach (DeviceInformation camera in _allVideoDevices)
            {
                if (CameraSelectionList.Items != null)
                {
                    CameraSelectionList.Items.Add(camera.Name);
                }
            }
        }

        private async void CameraSelectionList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedCameraItem = e.AddedItems.FirstOrDefault().ToString();
            foreach (DeviceInformation item in _allVideoDevices)
            {
                if (string.Equals(item.Name, selectedCameraItem))
                {
                    _desiredDevice = item;
                    await StartDeviceAsync();
                }
            }
        }

        private async void TakePhotoButton_ClickAsync(object sender, RoutedEventArgs e)
        {
            try
            {
                Debug.WriteLine("Taking photo");
                TakePhotoButton.IsEnabled = false;

                //store the captured image
                _photoFile = await KnownFolders.PicturesLibrary.CreateFileAsync("capturedImage", CreationCollisionOption.ReplaceExisting);
                Debug.WriteLine("Create photo file successful");

                //create the properties to write 
                ImageEncodingProperties imageProperties = ImageEncodingProperties.CreateJpeg();
                await _mediaCapture.CapturePhotoToStorageFileAsync(imageProperties, _photoFile);

                TakePhotoButton.IsEnabled = true;
                Debug.WriteLine("Photo taken");

                //map the captured image as Bitmap image to the right column
                ImageElement.Source = await OpenImageAsBitmapAsync(_photoFile);
            }
            catch (Exception exception)
            {
                Debug.WriteLine(exception);
                TakePhotoButton.IsEnabled = true;
            }
        }

        private async void GetDetailsButton_ClickAsync(object sender, RoutedEventArgs e)
        {
            GetDetailsErrorTextBlock.Text = string.Empty;

            if (_photoFile != null)
            {
                using (IRandomAccessStream stream = await _photoFile.OpenAsync(FileAccessMode.Read))
                {
                    // Create image decoder.
                    BitmapDecoder decoder = await BitmapDecoder.CreateAsync(stream);

                    // Load bitmap.
                    SoftwareBitmap bitmap = await decoder.GetSoftwareBitmapAsync();

                    // Extract text from image.
                    OcrResult result = await _ocrEngine.RecognizeAsync(bitmap);
                    if (string.IsNullOrEmpty(result.Text))
                    {
                        GetDetailsErrorTextBlock.Text = "Text not Recognizable try again!";
                        Debug.WriteLine("The Text is not recognizable.");
                    }
                    else
                    {
                        Debug.WriteLine(result.Text);

                        //extract the details
                        ApplyPatternMatching(result);
                    }
                }
            }
        }

        #region Camera_Methods
        private async Task StartDeviceAsync()
        {
            if (_desiredDevice != null)
            {
                try
                {
                    Debug.WriteLine("Starting device");
                    _mediaCapture = new MediaCapture();

                    //initialize the selected device
                    await _mediaCapture.InitializeAsync(
                        new MediaCaptureInitializationSettings
                        {
                            VideoDeviceId = _desiredDevice.Id
                        });

                    // if you have a valid camera then enable the photo button and start the preview window display
                    if (_mediaCapture.MediaCaptureSettings.VideoDeviceId != string.Empty
                        && _mediaCapture.MediaCaptureSettings.AudioDeviceId != string.Empty)
                    {
                        TakePhotoButton.IsEnabled = true;
                        Debug.WriteLine("Device initialized successful");
                        await StartPreviewAsync();
                    }
                    else
                    {
                        TakePhotoButton.IsEnabled = false;
                        Debug.WriteLine("Error - No VideoDevice/AudioDevice Found");
                    }
                }
                catch (Exception exception)
                {
                    Debug.WriteLine(exception);
                }
            }
        }

        private async Task StartPreviewAsync()
        {
            try
            {
                Debug.WriteLine("Starting preview");
                //set the source to the camera feed
                PreviewElement.Source = _mediaCapture;
                await _mediaCapture.StartPreviewAsync();

                Debug.WriteLine("Start preview successful");
            }
            catch (Exception exception)
            {
                PreviewElement.Source = null;
                Debug.WriteLine(exception);
            }
        }
        #endregion

        #region Helper_Methods
        //open an image file as a bitmapimage object 
        private async Task<BitmapImage> OpenImageAsBitmapAsync(StorageFile file)
        {
            IRandomAccessStreamWithContentType stream = await file.OpenReadAsync();
            BitmapImage bmpImg = new BitmapImage();
            bmpImg.SetSource(stream);

            return bmpImg;
        }
        #endregion

        #region OCR_Methods
        private void ApplyPatternMatching(OcrResult ocrResult)
        {
        }
        #endregion
    }
}
