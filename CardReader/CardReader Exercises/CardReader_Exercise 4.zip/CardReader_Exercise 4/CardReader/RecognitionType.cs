﻿namespace CardReader
{
    public enum RecognitionType
    {
        Other,
        Email,
        WebPage,
        Name,
        PhoneNumber,
        Number
    }
}
